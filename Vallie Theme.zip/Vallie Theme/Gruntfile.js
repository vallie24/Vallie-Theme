/* global module:true 
 * 
 * Gruntfile.js
 * npm install -g grunt-cli
 * npm install grunt-contrib-less grunt-contrib-watch grunt-contrib-connect --save-dev
 */
'use strict';
module.exports = function(grunt) {
  
  var serveStatic = require('serve-static');

  var phpMiddleware = require('connect-php');
  
  var modRewrite = require('connect-modrewrite');

  grunt.initConfig({

    // Less files are in app/less, output is in app/css
    less: {
      development: {
        options: {
          paths: ["./less"],
          yuicompress: false
        },
        files: {
        "./css/custom-style.css": "./less/style.less"
        }
      }
    },

    watch: {
      options: {
        livereload: 35729
      },
      files: "./less/*.less",
      tasks: ["less"]
    },

    cssmin: {
      target: {
        files: [{
          expand: true,
          cwd: 'css/',
          src: ['*.css', '!*.min.css'],
          dest: 'css/',
          ext: '.min.css'
        }]
      }
    },

    uglify: {
      dist: {
          options: {
              sourceMap: 'js/map/source-map.js'
          },
          files: {
              'js/plugins.min.js': [
                  'js/source/plugins.js',
                  'js/vendor/**/*.js',
                  'js/vendor/modernizr*.js'
              ],
              'js/main.min.js': [
                  'js/source/main.js'
              ]
          }
        }
      }
    });

  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-connect');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-livereload');
  grunt.loadNpmTasks('grunt-contrib-cssmin');

  // Run grunt server to get going
  grunt.registerTask('serve', [
    'watch'
  ]);

  grunt.registerTask('server', function () {
    grunt.log.warn('The `server` task has been deprecated. Use `grunt serve` to start a server.');
    grunt.task.run(['serve']);
  });
};